from django.apps import AppConfig


class DjangoWithPostgresqlAppConfig(AppConfig):
    name = 'django_with_PostgreSQL_app'


